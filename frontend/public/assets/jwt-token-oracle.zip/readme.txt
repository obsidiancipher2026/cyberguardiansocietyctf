﻿JWT Token Oracle - asset bundle

- token_sample.jwt: intercepted token from the target auth gate
- /jwks.json exposes the public key used by the server
- Exploit RS256->HS256 confusion to forge an admin token
