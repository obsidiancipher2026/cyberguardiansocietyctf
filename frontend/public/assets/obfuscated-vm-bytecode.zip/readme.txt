﻿Obfuscated VM Bytecode - asset bundle

- vm_blob.bin: bytecode payload executed by the custom VM
- Disassemble opcodes from the ELF dispatch table at 0x4020
- 0x0F = XOR opcode
