﻿Heap Master III - asset bundle

- heap3: challenge binary (glibc 2.31, Ubuntu 20.04)
- Run: ./heap3
- Exploit the double-free in delete to poison tcache and overwrite __free_hook
